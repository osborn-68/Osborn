rootProject.name = "demo"
include("app")
